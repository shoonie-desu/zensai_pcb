G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.0*
G04 #@! TF.CreationDate,2025-03-19T12:21:02+09:00*
G04 #@! TF.ProjectId,i8,69382e6b-6963-4616-945f-706362585858,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.0) date 2025-03-19 12:21:02*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.000000X1.000000*%
%ADD11O,1.000000X1.000000*%
%ADD12RoundRect,0.300000X1.697056X0.000000X0.000000X1.697056X-1.697056X0.000000X0.000000X-1.697056X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X5079999Y-6200003D03*
D11*
X3809998Y-6200003D03*
X2539999Y-6200003D03*
X1269999Y-6200003D03*
X0Y-6200003D03*
G04 #@! TD*
D12*
G04 #@! TO.C,PSW1*
X-12249999Y-5250001D03*
X-8714465Y-8785535D03*
G04 #@! TD*
G04 #@! TO.C,PSW2*
X-15785535Y-8785535D03*
X-12250001Y-12321069D03*
G04 #@! TD*
M02*
